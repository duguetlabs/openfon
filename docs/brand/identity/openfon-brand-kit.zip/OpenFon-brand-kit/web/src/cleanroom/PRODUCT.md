# Product
<!-- impeccable:product-schema 1 -->
## Platform
web
## Users
Small-business operators who need a voice receptionist. Brief supplied by coordinating agent on behalf of user.
## Product Purpose
Help a business configure its receptionist, supply business information, try it in a browser, and review messages and callback outcomes.
## Capabilities and Constraints
Backend voice/model choices must remain configurable and portable, including Kataleptic. Availability and integration behavior will come from a UI-neutral API contract. No deployment, migration, carrier spending, commit, or PR is authorized in this design work.
## Brand Commitments
OpenFon. Friendly, simpler customer experience and a complete visual and interaction remake. Explicitly do not inspect, reuse, or derive from the incumbent frontend.
## Product Principles
- Begin with the business owner's job.
- Make the receptionist understandable and testable before requiring technical decisions.
- Keep advanced backend configuration reachable through progressive disclosure.
- Show actual runtime state, never imply a call or provider capability was validated merely by displaying it.
## Open Decisions
Exact business sector is unspecified; default copy must remain sector-neutral. New aesthetic and interaction structure are delegated to the clean-room designer.
